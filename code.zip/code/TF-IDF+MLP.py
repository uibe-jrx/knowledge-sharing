##### 导入必要库
import pandas as pd
import numpy as np
import jieba
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import classification_report, accuracy_score, precision_score, recall_score, f1_score
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.utils import to_categorical

# 步骤 1: 数据加载
train_data_path = "/train.xlsx"  # 训练集路径
val_data_path = r"/test.xlsx"

# 加载训练集和验证集
train_data = pd.read_excel(train_data_path)
val_data = pd.read_excel(val_data_path)

# 假设数据集包含两列：句子 和 社会支持
train_texts = train_data['句子'].values  # 训练集文本数据
val_texts = val_data['句子'].values  # 验证集文本数据
train_labels = train_data['社会支持'].values  # 训练集标签
val_labels = val_data['社会支持'].values  # 验证集标签

# 步骤 2: 加载停用词
stopwords_path = "/baidu_stopwords.txt"  # 停用词路径
with open(stopwords_path, 'r', encoding='utf-8') as f:
    stopwords = set(f.read().splitlines())

# 步骤 3: 数据清洗与分词
def preprocess_text(text):
    # 去除非中文字符
    text = re.sub(r'[^\u4e00-\u9fa5]', ' ', text)
    # 分词并去除停用词
    words = jieba.cut(text)
    words = [word for word in words if word not in stopwords and word.strip()]
    return ' '.join(words)

# 对所有文本进行处理
cleaned_train_texts = [preprocess_text(text) for text in train_texts]
cleaned_val_texts = [preprocess_text(text) for text in val_texts]

# 步骤 4: 标签编码
label_mapping = {'情感支持': 0, '信息支持': 1, '有形支持': 2, '废话': 3}  # 标签映射
encoded_train_labels = np.array([label_mapping[label] for label in train_labels])
encoded_val_labels = np.array([label_mapping[label] for label in val_labels])

# 步骤 5: 特征提取（TF-IDF）
vectorizer = TfidfVectorizer(max_features=5000)  # 限制特征数量，避免过拟合
X_train_tfidf = vectorizer.fit_transform(cleaned_train_texts).toarray()
X_val_tfidf = vectorizer.transform(cleaned_val_texts).toarray()

# 步骤 6: 标签独热编码
y_train_one_hot = to_categorical(encoded_train_labels, num_classes=4)
y_val_one_hot = to_categorical(encoded_val_labels, num_classes=4)

# 步骤 7: 构建MLP模型
model = Sequential()
model.add(Dense(256, input_shape=(X_train_tfidf.shape[1],), activation='relu'))  # 输入层
model.add(Dropout(0.5))  # 随机失活，防止过拟合
model.add(Dense(128, activation='relu'))  # 隐藏层
model.add(Dropout(0.5))
model.add(Dense(4, activation='softmax'))  # 输出层（4个类别）

# 编译模型
model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# 步骤 8: 训练模型
model.fit(X_train_tfidf, y_train_one_hot, epochs=10, batch_size=32, validation_data=(X_val_tfidf, y_val_one_hot))

# 步骤 9: 模型评估
y_pred_probs = model.predict(X_val_tfidf)  # 概率输出
y_pred = np.argmax(y_pred_probs, axis=1)  # 获取预测的类别

# 分类报告
print("分类报告：")
print(classification_report(encoded_val_labels, y_pred, target_names=['情感支持', '信息支持', '有形支持', '废话']))

# 准确率、精确率、召回率、F1 等指标
accuracy = accuracy_score(encoded_val_labels, y_pred)
precision_weighted = precision_score(encoded_val_labels, y_pred, average='weighted')
recall_weighted = recall_score(encoded_val_labels, y_pred, average='weighted')
f1_weighted = f1_score(encoded_val_labels, y_pred, average='weighted')

# 宏平均精确率、召回率、F1
precision_macro = precision_score(encoded_val_labels, y_pred, average='macro')
recall_macro = recall_score(encoded_val_labels, y_pred, average='macro')
f1_macro = f1_score(encoded_val_labels, y_pred, average='macro')

# 打印所有指标
print(f"准确率: {round(accuracy, 4)}")
print(f"加权精确率: {round(precision_weighted, 4)}")
print(f"加权召回率: {round(recall_weighted, 4)}")
print(f"加权F1分数: {round(f1_weighted, 4)}")

print(f"宏精确率: {round(precision_macro, 4)}")
print(f"宏召回率: {round(recall_macro, 4)}")
print(f"宏F1分数: {round(f1_macro, 4)}")



