import pandas as pd
import numpy as np
import jieba
from sklearn.model_selection import train_test_split
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Embedding, Conv1D, MaxPooling1D, GlobalMaxPooling1D, Dense, Dropout
from gensim.models import KeyedVectors
from sklearn.metrics import classification_report, accuracy_score, precision_score, recall_score, f1_score

# 1. 数据加载和预处理
# 加载训练集和验证集
train_data = pd.read_excel("/train.xlsx")
val_data = pd.read_excel(r"/test.xlsx")

with open("C:/Users/xiaoj/Desktop/stopwords-master/baidu_stopwords.txt", 'r', encoding='utf-8') as f:
    stopwords = set(f.read().splitlines())

def preprocess_text(text):
    words = jieba.cut(text)
    return " ".join([word for word in words if word.strip() and word not in stopwords])

# 对训练集和验证集进行文本清洗
train_data['cleaned_text'] = train_data['句子'].apply(preprocess_text)
val_data['cleaned_text'] = val_data['句子'].apply(preprocess_text)

# 社会支持标签映射
label_mapping = {'情感支持': 0, '信息支持': 1, '有形支持': 2, '废话': 3}
train_data['label'] = train_data['社会支持'].map(label_mapping)
val_data['label'] = val_data['社会支持'].map(label_mapping)

# 提取文本和标签
X_train = train_data['cleaned_text'].values
X_val = val_data['cleaned_text'].values
y_train = train_data['label'].values
y_val = val_data['label'].values

# 2. 文本序列化
tokenizer = Tokenizer(num_words=10000)
tokenizer.fit_on_texts(X_train)  # 只使用训练集来拟合词汇表

X_train_seq = tokenizer.texts_to_sequences(X_train)
X_val_seq = tokenizer.texts_to_sequences(X_val)

# 对训练集和验证集的文本进行补齐，使得它们的长度一致
X_train_padded = pad_sequences(X_train_seq, maxlen=100)
X_val_padded = pad_sequences(X_val_seq, maxlen=100)

# 3. 加载预训练 Word2Vec 模型
word2vec_path = "/sgns.literature.word"  # 替换为实际路径
word2vec = KeyedVectors.load_word2vec_format(word2vec_path, binary=False)

# 4. 构建嵌入矩阵
embedding_dim = word2vec.vector_size
vocab_size = len(tokenizer.word_index) + 1
embedding_matrix = np.zeros((vocab_size, embedding_dim))

for word, i in tokenizer.word_index.items():
    if i < vocab_size:
        if word in word2vec:
            embedding_matrix[i] = word2vec[word]

# 5. 替换嵌入层并构建模型
model = Sequential([
    Embedding(input_dim=vocab_size,
              output_dim=embedding_dim,
              weights=[embedding_matrix],
              input_length=100,
              trainable=False),  # 冻结嵌入层
    Conv1D(128, 5, activation='relu'),
    MaxPooling1D(pool_size=2),
    GlobalMaxPooling1D(),
    Dense(64, activation='relu'),
    Dropout(0.5),
    Dense(4, activation='softmax')
])

model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# 6. 模型训练
model.fit(X_train_padded, y_train, validation_data=(X_val_padded, y_val), epochs=5, batch_size=32)

# 7. 模型评估
y_pred = model.predict(X_val_padded)
y_pred_labels = np.argmax(y_pred, axis=1)

# 打印准确率
accuracy = accuracy_score(y_val, y_pred_labels)
print(f"准确率: {round(accuracy * 100, 2)}%")

# 计算加权精确率、未加权平均精确率、加权召回率、未加权平均召回率、加权F1、宏F1
weighted_precision = precision_score(y_val, y_pred_labels, average='weighted')
unweighted_precision = precision_score(y_val, y_pred_labels, average='macro')
weighted_recall = recall_score(y_val, y_pred_labels, average='weighted')
unweighted_recall = recall_score(y_val, y_pred_labels, average='macro')
weighted_f1 = f1_score(y_val, y_pred_labels, average='weighted')
macro_f1 = f1_score(y_val, y_pred_labels, average='macro')

# 打印各项指标并乘以100显示为百分比
print(f"加权精确率: {round(weighted_precision * 100, 2)}%")
print(f"未加权平均精确率: {round(unweighted_precision * 100, 2)}%")
print(f"加权召回率: {round(weighted_recall * 100, 2)}%")
print(f"未加权平均召回率: {round(unweighted_recall * 100, 2)}%")
print(f"加权F1分数: {round(weighted_f1 * 100, 2)}%")
print(f"宏F1分数: {round(macro_f1 * 100, 2)}%")

# 打印分类报告
print(classification_report(y_val, y_pred_labels, target_names=label_mapping.keys(), digits=4))



