####### 步骤 1: 加载数据
import pandas as pd

# 加载训练集和验证集数据
train_data = pd.read_excel('/train.xlsx')
test_data = pd.read_excel(r"/test.xlsx")

# 查看数据结构
print("训练集样本数:", train_data.shape[0])
print("验证集样本数:", test_data.shape[0])
print(train_data.head())
print(test_data.head())

#### 步骤 2: 清洗文本数据
import jieba
import re

# 加载停用词
def load_stopwords(filepath):
    with open(filepath, 'r', encoding='utf-8') as file:
        stopwords = set(file.read().splitlines())
    return stopwords

stopwords = load_stopwords("/baidu_stopwords.txt")

# 文本清洗函数
def clean_text(text, stopwords):
    # 转为小写
    text = text.lower()
    # 去除非中文字符
    text = re.sub(r'[^\u4e00-\u9fa5]', ' ', text)
    # 分词并去停用词
    words = jieba.cut(text)
    words = [word for word in words if word not in stopwords and word.strip() != '']
    return " ".join(words)

# 对训练集和验证集的文本进行清洗
train_data['cleaned_text'] = train_data['句子'].apply(lambda x: clean_text(x, stopwords))
test_data['cleaned_text'] = test_data['句子'].apply(lambda x: clean_text(x, stopwords))

# 查看清洗结果
print(train_data[['句子', 'cleaned_text']].head())
print(test_data[['句子', 'cleaned_text']].head())

#### 步骤 3: 特征提取
from sklearn.feature_extraction.text import TfidfVectorizer

# 初始化 TF-IDF 向量化器
vectorizer = TfidfVectorizer(max_features=5000)

# 将清洗后的文本转化为 TF-IDF 特征矩阵
X_train = vectorizer.fit_transform(train_data['cleaned_text'])
X_test = vectorizer.transform(test_data['cleaned_text'])

# 查看特征矩阵形状
print("训练集 TF-IDF 特征矩阵形状:", X_train.shape)
print("验证集 TF-IDF 特征矩阵形状:", X_test.shape)

#### 步骤 4: 标签编码
from sklearn.preprocessing import LabelEncoder

# 编码社会支持类型
support_encoder = LabelEncoder()
train_data['support_encoded'] = support_encoder.fit_transform(train_data['社会支持'])
test_data['support_encoded'] = support_encoder.transform(test_data['社会支持'])

# 查看编码后的数据
print(train_data[['社会支持', 'support_encoded']].head())
print(test_data[['社会支持', 'support_encoded']].head())

#### 步骤 5: 划分训练集和测试集
# 注意：此时我们已经将训练集和验证集加载并清洗完成，无需再进行数据划分。

# 查看数据集划分结果
print("训练集样本数:", X_train.shape[0], "验证集样本数:", X_test.shape[0])

#### 步骤 6: 训练 SVM 模型
from sklearn.svm import SVC

# 初始化 SVM 模型
svm_model = SVC(kernel='linear', C=1)

# 训练模型
svm_model.fit(X_train, train_data['support_encoded'])

# 预测
y_pred = svm_model.predict(X_test)

#### 步骤 7: 评估模型
from sklearn.metrics import classification_report, accuracy_score, precision_score, recall_score, f1_score

# 打印分类报告
report = classification_report(test_data['support_encoded'], y_pred, digits=4, target_names=support_encoder.classes_)
print("分类报告：")
print(report)

# 计算准确率
accuracy = accuracy_score(test_data['support_encoded'], y_pred)
print("准确率: {:.2f}%".format(accuracy * 100))

# 计算加权精确率、加权召回率、加权F1分数
weighted_precision = precision_score(test_data['support_encoded'], y_pred, average='weighted')
weighted_recall = recall_score(test_data['support_encoded'], y_pred, average='weighted')
weighted_f1 = f1_score(test_data['support_encoded'], y_pred, average='weighted')

print("加权精确率: {:.2f}%".format(weighted_precision * 100))
print("加权召回率: {:.2f}%".format(weighted_recall * 100))
print("加权F1分数: {:.2f}%".format(weighted_f1 * 100))

# 计算宏精确率、宏召回率、宏F1分数
macro_precision = precision_score(test_data['support_encoded'], y_pred, average='macro')
macro_recall = recall_score(test_data['support_encoded'], y_pred, average='macro')
macro_f1 = f1_score(test_data['support_encoded'], y_pred, average='macro')

print("宏精确率: {:.2f}%".format(macro_precision * 100))
print("宏召回率: {:.2f}%".format(macro_recall * 100))
print("宏F1分数: {:.2f}%".format(macro_f1 * 100))





