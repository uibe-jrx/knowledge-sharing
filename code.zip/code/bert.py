import torch
from torch.utils.data import Dataset, DataLoader
from transformers import BertTokenizer, BertForSequenceClassification, Trainer, TrainingArguments
import pandas as pd
from sklearn.metrics import accuracy_score, precision_recall_fscore_support, classification_report, precision_score, recall_score, f1_score

# 标签映射字典，将社会支持类型转换为整数
label_mapping = {
    '情感支持': 0,
    '信息支持': 1,
    '有形支持': 2,
    '废话': 3
}


# 自定义数据集类
class SocialSupportDataset(Dataset):
    def __init__(self, dataframe, tokenizer, max_len=128):
        self.dataframe = dataframe
        self.tokenizer = tokenizer
        self.max_len = max_len

    def __len__(self):
        return len(self.dataframe)

    def __getitem__(self, item):
        sentence = self.dataframe.iloc[item]["句子"]
        label = self.dataframe.iloc[item]["社会支持"]

        # 将标签从字符串映射为整数
        label = label_mapping[label]

        encoding = self.tokenizer.encode_plus(
            sentence,
            add_special_tokens=True,
            max_length=self.max_len,
            padding='max_length',
            truncation=True,
            return_tensors="pt"
        )

        input_ids = encoding['input_ids'].flatten()
        attention_mask = encoding['attention_mask'].flatten()

        return {
            'input_ids': input_ids,
            'attention_mask': attention_mask,
            'labels': torch.tensor(label, dtype=torch.long)
        }


# 加载数据
train_df = pd.read_excel("test.xlsx")
val_df = pd.read_excel(r"ouput.xlsx")

# 初始化BERT tokenizer
tokenizer = BertTokenizer.from_pretrained("/bert_base_chinese")

# 创建数据集
train_dataset = SocialSupportDataset(train_df, tokenizer)
val_dataset = SocialSupportDataset(val_df, tokenizer)

# 定义训练参数
training_args = TrainingArguments(
    output_dir='./results',
    evaluation_strategy="epoch",  # 每个epoch评估一次
    learning_rate=2e-5,
    per_device_train_batch_size=16,
    per_device_eval_batch_size=16,
    num_train_epochs=3,
    weight_decay=0.01,
    logging_dir='./logs',
)

# 加载模型
model = BertForSequenceClassification.from_pretrained("bert_base_chinese",
                                                      num_labels=4)


# 定义计算评估指标的函数
def compute_metrics(p):
    predictions, labels = p
    preds = torch.argmax(torch.tensor(predictions), axis=1)

    # 计算总体准确率
    accuracy = accuracy_score(labels, preds)

    # 计算每个类别的精确率、召回率和F1得分
    precision, recall, f1, support = precision_recall_fscore_support(labels, preds, average=None, zero_division=1)

    # 计算加权精确率、未加权平均精确率、加权召回率、未加权平均召回率、加权F1、宏F1
    precision_weighted = precision_score(labels, preds, average='weighted') * 100
    precision_macro = precision_score(labels, preds, average='macro') * 100
    recall_weighted = recall_score(labels, preds, average='weighted') * 100
    recall_macro = recall_score(labels, preds, average='macro') * 100
    f1_weighted = f1_score(labels, preds, average='weighted') * 100
    f1_macro = f1_score(labels, preds, average='macro') * 100

    # 将结果存储到字典中，包含每个类别和整体准确率
    metrics = {
        'accuracy': accuracy,
        'precision': precision.tolist(),
        'recall': recall.tolist(),
        'f1': f1.tolist(),
        'support': support.tolist(),
        'precision_weighted': precision_weighted,
        'precision_macro': precision_macro,
        'recall_weighted': recall_weighted,
        'recall_macro': recall_macro,
        'f1_weighted': f1_weighted,
        'f1_macro': f1_macro
    }

    return metrics


# 定义Trainer
trainer = Trainer(
    model=model,
    args=training_args,
    train_dataset=train_dataset,
    eval_dataset=val_dataset,
    compute_metrics=compute_metrics
)

# 训练模型
trainer.train()

# 保存模型
model.save_pretrained("./saved_model")
tokenizer.save_pretrained("./saved_model")

# 使用训练后的模型进行预测
predictions, labels, _ = trainer.predict(val_dataset)


# 将预测结果转换为分类报告所需的格式
predictions = torch.argmax(torch.tensor(predictions), axis=1)

# 打印分类报告，保留四位小数
print(classification_report(labels, predictions, target_names=['情感支持', '信息支持', '有形支持', '废话'], digits=4))

# 输出加权精确率、未加权平均精确率、加权召回率、未加权平均召回率、加权F1、宏F1
print(f"\n加权精确率: {trainer.compute_metrics((predictions, labels))['precision_weighted']:.2f}%")
print(f"未加权平均精确率: {trainer.compute_metrics((predictions, labels))['precision_macro']:.2f}%")
print(f"加权召回率: {trainer.compute_metrics((predictions, labels))['recall_weighted']:.2f}%")
print(f"未加权平均召回率: {trainer.compute_metrics((predictions, labels))['recall_macro']:.2f}%")
print(f"加权F1: {trainer.compute_metrics((predictions, labels))['f1_weighted']:.2f}%")
print(f"宏F1: {trainer.compute_metrics((predictions, labels))['f1_macro']:.2f}%")
