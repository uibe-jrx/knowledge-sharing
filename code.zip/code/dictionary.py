import pandas as pd
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score

# 1. 加载数据集
extracted_file = ""
true_file = ""

# 加载提取后的文件和真值文件
extracted_data = pd.read_csv(extracted_file, encoding='utf-8')
true_data = pd.read_csv(true_file, encoding='utf-8')

# 2. 确保两个文件按段落顺序对齐
if len(extracted_data) != len(true_data):
    raise ValueError("提取后的文件和真值文件的段落数量不一致，请检查文件内容。")

# 3. 评估逻辑
def evaluate_extraction(predicted, truth):
    """
    评估单个段落的提取结果是否正确。
    :param predicted: 提取后的图书名称（字符串，使用“、”分隔）
    :param truth: 真值的图书名称（字符串，使用“、”分隔）
    :return: 是否正确（True/False）
    """
    # 将图书名称用“、”分隔为集合
    predicted_set = set(predicted.split("、")) if isinstance(predicted, str) else set()
    truth_set = set(truth.split("、")) if isinstance(truth, str) else set()
    # 如果预测结果中至少有一个图书名称在真值中，则认为正确
    return not predicted_set.isdisjoint(truth_set)  # 判断两个集合是否有交集

# 逐段评估
results = []
for idx, (predicted, truth) in enumerate(zip(extracted_data['图书名称'], true_data['图书名称'])):
    is_correct = evaluate_extraction(predicted, truth)
    results.append(is_correct)

# 4. 计算准确率、精确率、召回率和F1分数
y_true = [1 if truth else 0 for truth in true_data['图书名称']]
y_pred = results

accuracy = accuracy_score(y_true, y_pred)
precision = precision_score(y_true, y_pred)
recall = recall_score(y_true, y_pred)
f1 = f1_score(y_true, y_pred)

print(f"提取的图书名称准确率：{accuracy:.4%}")
print(f"提取的图书名称精确率：{precision:.4f}")
print(f"提取的图书名称召回率：{recall:.4f}")
print(f"提取的图书名称F1分数：{f1:.4f}")

# 5. 保存评估结果
extracted_data['是否正确'] = results
output_path = ""
extracted_data.to_csv(output_path, index=False, encoding='utf-8-sig')

print(f"评估结果已保存到：{output_path}")

