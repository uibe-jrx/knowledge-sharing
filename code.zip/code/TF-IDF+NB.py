import pandas as pd
import jieba
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report, accuracy_score, precision_score, recall_score, f1_score

# 1. 加载数据和停用词
# 加载训练集和验证集路径
train_file_path = "/train.xlsx"
val_file_path = "/test.xlsx"

# 停用词文件路径
stopwords_path = "/baidu_stopwords.txt"

# 加载训练集和验证集数据
train_data = pd.read_excel(train_file_path)
val_data = pd.read_excel(val_file_path)

# 查看数据结构，假设有两列："句子" 和 "社会支持"
print("训练集数据预览：")
print(train_data.head())

# 2. 文本预处理
texts_train = train_data['句子']
texts_val = val_data['句子']
labels_train = train_data['社会支持']
labels_val = val_data['社会支持']

# 加载停用词表
with open(stopwords_path, 'r', encoding='utf-8') as f:
    stopwords = set(f.read().splitlines())

# 定义分词函数
def tokenize(text):
    return ' '.join([word for word in jieba.lcut(text) if word not in stopwords])

# 对训练集和验证集的文本进行分词
texts_train_tokenized = texts_train.apply(tokenize)
texts_val_tokenized = texts_val.apply(tokenize)

# 将类别标签转化为数字
label_mapping = {label: idx for idx, label in enumerate(labels_train.unique())}
labels_train_mapped = labels_train.map(label_mapping)
labels_val_mapped = labels_val.map(label_mapping)

print("\n分词后的训练集样本预览：")
print(texts_train_tokenized.head())

print("\n分词后的验证集样本预览：")
print(texts_val_tokenized.head())

print("\n类别映射：", label_mapping)

# 3. 数据集划分（训练集和验证集已经提供，无需再拆分）
X_train = texts_train_tokenized
X_val = texts_val_tokenized
y_train = labels_train_mapped
y_val = labels_val_mapped

# 4. 特征提取（TF-IDF）
vectorizer = TfidfVectorizer(max_features=5000)  # 提取5000个高频词特征
X_train_tfidf = vectorizer.fit_transform(X_train)
X_val_tfidf = vectorizer.transform(X_val)

print("\n训练集TF-IDF特征矩阵大小：", X_train_tfidf.shape)
print("验证集TF-IDF特征矩阵大小：", X_val_tfidf.shape)

# 5. 模型训练
model = MultinomialNB()  # 初始化朴素贝叶斯分类器
model.fit(X_train_tfidf, y_train)

# 6. 模型评估
y_pred = model.predict(X_val_tfidf)

# 分类报告
print("\n分类报告：")
report = classification_report(y_val, y_pred, target_names=label_mapping.keys(), output_dict=True)

# 输出每个类别的指标，精确到四位小数
for label, metrics in report.items():
    if label != 'accuracy':  # 排除总准确率行
        print(f"{label:<10} {metrics['precision']:.4f} {metrics['recall']:.4f} {metrics['f1-score']:.4f} {metrics['support']}")

# 准确率、召回率、F1 值等指标
accuracy = accuracy_score(y_val, y_pred)
precision = precision_score(y_val, y_pred, average='weighted')
recall = recall_score(y_val, y_pred, average='weighted')
f1 = f1_score(y_val, y_pred, average='weighted')

# 打印加权精确率、未加权精确率、加权召回率、未加权召回率、加权F1、宏F1并乘以100
print(f"\n准确率: {accuracy * 100:.2f}%")
print(f"加权精确率: {precision * 100:.2f}%")
print(f"未加权平均精确率: {precision_score(y_val, y_pred, average='macro') * 100:.2f}%")
print(f"加权召回率: {recall * 100:.2f}%")
print(f"未加权平均召回率: {recall_score(y_val, y_pred, average='macro') * 100:.2f}%")
print(f"加权F1分数: {f1 * 100:.2f}%")
print(f"宏F1分数: {f1_score(y_val, y_pred, average='macro') * 100:.2f}%")

# 将报告转换为pandas DataFrame，以便对齐输出
report_df = pd.DataFrame(report).transpose()

# 打印格式化后的报告
print("\n格式化后的分类报告：")
print(report_df)



