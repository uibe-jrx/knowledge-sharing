import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from tensorflow.keras.preprocessing.text import Tokenizer
from tensorflow.keras.preprocessing.sequence import pad_sequences
from tensorflow.keras import layers, models
from tensorflow.keras.utils import to_categorical
import jieba
from sklearn.metrics import accuracy_score, classification_report, precision_score, recall_score, f1_score

# 1. 加载训练集和验证集数据
train_data_path = "/train.xlsx"
val_data_path = "/test.xlsx"

train_data = pd.read_excel(train_data_path)
val_data = pd.read_excel(val_data_path)

# 查看训练集数据结构
print("训练集数据预览：")
print(train_data.head())

# 2. 停用词加载
stopwords_path = "/baidu_stopwords.txt"
with open(stopwords_path, 'r', encoding='utf-8') as f:
    stopwords = set(f.read().splitlines())

# 3. 数据预处理 - 分词和去停用词
def preprocess_text(text):
    words = jieba.cut(text)
    words = [word for word in words if word not in stopwords and word.strip()]
    return ' '.join(words)

# 对训练集和验证集的文本进行分词
texts_train = train_data['句子'].apply(preprocess_text)
texts_val = val_data['句子'].apply(preprocess_text)

# 4. 标签编码
label_mapping = {'情感支持': 0, '信息支持': 1, '有形支持': 2, '废话': 3}
labels_train = np.array([label_mapping[label] for label in train_data['社会支持']])
labels_val = np.array([label_mapping[label] for label in val_data['社会支持']])

# 5. 数据集划分（已经给定，训练集和验证集分别使用）
X_train = texts_train
X_val = texts_val
y_train = labels_train
y_val = labels_val

# 6. 文本向量化（Tokenizer + Padding）
max_words = 10000  # 最大词汇量
max_sequence_length = 100  # 最大句子长度

tokenizer = Tokenizer(num_words=max_words)
tokenizer.fit_on_texts(X_train)

X_train_sequences = tokenizer.texts_to_sequences(X_train)
X_val_sequences = tokenizer.texts_to_sequences(X_val)

X_train_padded = pad_sequences(X_train_sequences, maxlen=max_sequence_length)
X_val_padded = pad_sequences(X_val_sequences, maxlen=max_sequence_length)

# 7. 标签独热编码
y_train_one_hot = to_categorical(y_train, num_classes=4)
y_val_one_hot = to_categorical(y_val, num_classes=4)

# 8. 构建LSTM模型
model = models.Sequential()
model.add(layers.Embedding(input_dim=len(tokenizer.word_index) + 1,
                           output_dim=100,  # 嵌入维度
                           input_length=max_sequence_length))
model.add(layers.LSTM(128))  # 不再使用return_sequences=True
model.add(layers.Dense(64, activation='relu'))
model.add(layers.Dense(4, activation='softmax'))  # 4个类别输出

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])

# 9. 模型训练
model.fit(X_train_padded, y_train_one_hot, epochs=10, batch_size=32, validation_data=(X_val_padded, y_val_one_hot))

# 10. 评估模型
score = model.evaluate(X_val_padded, y_val_one_hot, verbose=1)
print(f"验证集准确率: {score[1]:.4f}")  # 显示到四位小数

# 11. 预测并评估准确率和召回率
# 预测
y_pred = model.predict(X_val_padded)
y_pred_labels = np.argmax(y_pred, axis=1)  # 取得最大概率的类别作为预测结果

# 打印准确率
accuracy = accuracy_score(y_val, y_pred_labels)
print(f"准确率: {accuracy:.4f}")  # 显示到四位小数

# 获取分类报告
report = classification_report(y_val, y_pred_labels, target_names=['情感支持', '信息支持', '有形支持', '废话'],
                               output_dict=True)

# 输出格式化的分类报告（四位小数）
print("\n分类报告（四位小数）：")
print(f"{'类别':<10}{'precision':<10}{'recall':<10}{'f1-score':<10}{'support':<10}")
for label in ['情感支持', '信息支持', '有形支持', '废话']:
    precision = report[label]['precision']
    recall = report[label]['recall']
    f1_score_value = report[label]['f1-score']
    support = report[label]['support']

    print(f"{label:<10}{precision:.4f}{recall:.4f}{f1_score_value:.4f}{support:>10}")

# 计算加权精确率、未加权平均精确率、加权召回率、未加权平均召回率、加权F1、宏F1，并乘以100
precision_weighted = precision_score(y_val, y_pred_labels, average='weighted') * 100
precision_macro = precision_score(y_val, y_pred_labels, average='macro') * 100
recall_weighted = recall_score(y_val, y_pred_labels, average='weighted') * 100
recall_macro = recall_score(y_val, y_pred_labels, average='macro') * 100
f1_weighted = f1_score(y_val, y_pred_labels, average='weighted') * 100
f1_macro = f1_score(y_val, y_pred_labels, average='macro') * 100

# 输出
print(f"\n加权精确率: {precision_weighted:.2f}%")
print(f"未加权平均精确率: {precision_macro:.2f}%")
print(f"加权召回率: {recall_weighted:.2f}%")
print(f"未加权平均召回率: {recall_macro:.2f}%")
print(f"加权F1: {f1_weighted:.2f}%")
print(f"宏F1: {f1_macro:.2f}%")



