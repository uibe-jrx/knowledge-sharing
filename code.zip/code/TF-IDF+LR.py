import pandas as pd
import numpy as np
import jieba
import re
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import classification_report, accuracy_score, recall_score, f1_score, precision_score

# 步骤 1: 数据加载
train_data_path = "train/.xlsx"  # 训练集路径
val_data_path = "/test.xlsx"  # 验证集路径

# 加载训练集数据
train_data = pd.read_excel(train_data_path)
# 加载验证集数据
val_data = pd.read_excel(val_data_path)

# 假设数据集包含两列：句子 和 社会支持
train_texts = train_data['句子'].values  # 训练集文本数据
val_texts = val_data['句子'].values  # 验证集文本数据
train_labels = train_data['社会支持'].values  # 训练集标签
val_labels = val_data['社会支持'].values  # 验证集标签

# 步骤 2: 加载停用词
stopwords_path = "/baidu_stopwords.txt"  # 停用词路径
with open(stopwords_path, 'r', encoding='utf-8') as f:
    stopwords = set(f.read().splitlines())

# 步骤 3: 数据清洗与分词
def preprocess_text(text):
    # 去除非中文字符
    text = re.sub(r'[^\u4e00-\u9fa5]', ' ', text)
    # 分词并去除停用词
    words = jieba.cut(text)
    words = [word for word in words if word not in stopwords and word.strip()]
    return ' '.join(words)

# 对训练集和验证集的文本进行处理
train_cleaned_texts = [preprocess_text(text) for text in train_texts]
val_cleaned_texts = [preprocess_text(text) for text in val_texts]

# 步骤 4: 标签编码
label_mapping = {'情感支持': 0, '信息支持': 1, '有形支持': 2, '废话': 3}  # 标签映射
train_encoded_labels = np.array([label_mapping[label] for label in train_labels])
val_encoded_labels = np.array([label_mapping[label] for label in val_labels])

# 步骤 5: 特征提取（TF-IDF）
vectorizer = TfidfVectorizer(max_features=5000)  # 限制特征数量，避免过拟合
X_train_tfidf = vectorizer.fit_transform(train_cleaned_texts)  # 训练集特征提取
X_val_tfidf = vectorizer.transform(val_cleaned_texts)  # 验证集特征提取

# 步骤 6: 构建逻辑回归模型
model = LogisticRegression(multi_class='multinomial', solver='lbfgs', max_iter=1000)
model.fit(X_train_tfidf, train_encoded_labels)

# 步骤 7: 模型评估
y_pred = model.predict(X_val_tfidf)

# 分类报告
print("分类报告：")
print(classification_report(val_encoded_labels, y_pred, target_names=['情感支持', '信息支持', '有形支持', '废话']))

# 准确率、召回率、F1 值等指标
accuracy = accuracy_score(val_encoded_labels, y_pred)
precision = precision_score(val_encoded_labels, y_pred, average='weighted')
recall = recall_score(val_encoded_labels, y_pred, average='weighted')
f1 = f1_score(val_encoded_labels, y_pred, average='weighted')

# 加权精确率、未加权平均精确率、加权召回率、未加权平均召回率、加权F1、宏F1，并乘以100显示百分比
precision_weighted = precision * 100
precision_macro = precision_score(val_encoded_labels, y_pred, average='macro') * 100
recall_weighted = recall * 100
recall_macro = recall_score(val_encoded_labels, y_pred, average='macro') * 100
f1_weighted = f1 * 100
f1_macro = f1_score(val_encoded_labels, y_pred, average='macro') * 100

# 输出指标
print(f"\n准确率: {accuracy * 100:.2f}%")
print(f"加权精确率: {precision_weighted:.2f}%")
print(f"未加权平均精确率: {precision_macro:.2f}%")
print(f"加权召回率: {recall_weighted:.2f}%")
print(f"未加权平均召回率: {recall_macro:.2f}%")
print(f"加权F1: {f1_weighted:.2f}%")
print(f"宏F1: {f1_macro:.2f}%")
